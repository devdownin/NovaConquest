---
name: Graphic Noir Futurism
colors:
  surface: '#101417'
  surface-dim: '#101417'
  surface-bright: '#363a3d'
  surface-container-lowest: '#0b0f12'
  surface-container-low: '#181c1f'
  surface-container: '#1c2023'
  surface-container-high: '#272a2e'
  surface-container-highest: '#323539'
  on-surface: '#e0e2e7'
  on-surface-variant: '#c6c6ca'
  inverse-surface: '#e0e2e7'
  inverse-on-surface: '#2d3134'
  outline: '#8f9094'
  outline-variant: '#45474a'
  surface-tint: '#c6c6ca'
  primary: '#c6c6ca'
  on-primary: '#2f3034'
  primary-container: '#111316'
  on-primary-container: '#7d7e81'
  inverse-primary: '#5d5e62'
  secondary: '#ffb4ab'
  on-secondary: '#690006'
  secondary-container: '#d30017'
  on-secondary-container: '#ffe2de'
  tertiary: '#00dce6'
  on-tertiary: '#00373a'
  tertiary-container: '#001618'
  on-tertiary-container: '#008c93'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#e2e2e6'
  primary-fixed-dim: '#c6c6ca'
  on-primary-fixed: '#1a1c1f'
  on-primary-fixed-variant: '#45474a'
  secondary-fixed: '#ffdad6'
  secondary-fixed-dim: '#ffb4ab'
  on-secondary-fixed: '#410002'
  on-secondary-fixed-variant: '#93000c'
  tertiary-fixed: '#6ff6ff'
  tertiary-fixed-dim: '#00dce6'
  on-tertiary-fixed: '#002022'
  on-tertiary-fixed-variant: '#004f53'
  background: '#101417'
  on-background: '#e0e2e7'
  surface-variant: '#323539'
typography:
  display-lg:
    fontFamily: Space Grotesk
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.2'
  headline-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.2'
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  stat-label:
    fontFamily: Geist
    fontSize: 12px
    fontWeight: '600'
    lineHeight: '1'
    letterSpacing: 0.1em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 4px
  gutter-xs: 8px
  gutter-md: 16px
  margin-mobile: 16px
  margin-desktop: 32px
  panel-padding: 20px
---

## Brand & Style

This design system establishes a visual language for a gritty, high-stakes interstellar strategy experience. Drawing inspiration from Enki Bilal’s graphic novels, the aesthetic merges **Hard Industrialism** with **High-Tech Noir**. 

The UI is designed to feel like a tactile terminal within a worn-out starship cockpit—functional, slightly weathered, yet pulsing with neon energy. We utilize a fusion of **Glassmorphism** for data overlays and **Brutalism** for structural framing. Key stylistic hallmarks include halftone patterns, digital noise textures, and mechanical "mounting bolt" accents in the corners of major panels to emphasize a sense of physical construction.

## Colors

The palette is anchored in a deep, void-like background that allows neon accents to pierce through the "noise." 

- **The Void (#111316):** The base surface for all views, representing the cold expanse of space.
- **Dominion Red (#FF3131):** Used for aggressive UI states, combat alerts, and Dominion-affiliated iconography.
- **Xylar Cyan (#00F3FF):** Used for scanning, technical data, and Xylar-specific interfaces.
- **Trader Gold (#FFD700):** Reserved for commerce, rare resources, and premium interactions.
- **Industrial Gray (#8A8D91):** The color of "metal"—used for borders, mounting bolts, and inactive states.

Apply a subtle **Static Noise** texture overlay (low opacity) across the primary background to avoid "flat" digital blacks.

## Typography

Typography balances technical precision with high-impact editorial style.

- **Space Grotesk** serves as the primary headline face. Its geometric construction feels engineered and futuristic. Use it for mission titles, planet names, and major headers.
- **Inter** provides high legibility for narrative text, transmission logs, and system descriptions.
- **Geist** is reserved for tactical data, coordinates, and ship stats. Its monospaced rhythm suggests real-time code and sensor readouts.

Always use **Uppercase** for labels and stats to maintain an authoritative military-industrial tone.

## Layout & Spacing

This design system uses a **density-first layout**. Strategy games require significant information on screen, so margins are kept tight.

- **Grid Model:** 4-column for mobile, 12-column for tablet/desktop.
- **Safe Zones:** Use a 16px internal margin on mobile to prevent UI elements from hitting the edge of the glass.
- **Industrial Framing:** Panels should feel "bolted" into the corners. Content should be grouped into rigid containers rather than floating freely.
- **Visual Hierarchy:** Use wide spacing (32px+) only to separate distinct game modes (e.g., Star Map vs. Ship Management). Internal module spacing should stay tight (8px-12px) to feel like an integrated dashboard.

## Elevation & Depth

In a Graphic Noir environment, depth is achieved through **Tonal Stacking** and **Glassmorphism** rather than traditional shadows.

1.  **Backdrop Layer:** The deep space background with a halftone and noise filter.
2.  **Container Layer:** Frosted glass panels (`blur: 20px`, `opacity: 60%`) with a thin 1px border in Industrial Gray.
3.  **Active Layer:** Neon-bordered elements that appear to "glow" onto the surface below using a soft, colored outer-glow (0px 0px 15px with faction color).
4.  **The Bolt Effect:** Every primary panel corner features a small 4px circle (the "bolt") in a high-contrast metallic gray to ground the UI in the physical world.

## Shapes

The shape language is **aggressive and angular**. 

While the base `roundedness` is set to Soft (4px), we frequently use **clipped corners** (45-degree chamfers) for primary action buttons and headers to reinforce the sci-fi aesthetic. 
- **Standard UI Elements:** 4px radius.
- **Interactive Buttons:** Clipped corners on the top-right and bottom-left.
- **Status Tags:** Hard 0px edges.
- **Resource Icons:** Circular, but contained within hexagonal frames.

## Components

### Buttons
- **Primary:** Clipped-corner shape with a solid faction-color fill. On hover/active, add a high-intensity neon outer glow.
- **Secondary:** Transparent background, 1px Industrial Gray border, with faction-colored text.
- **Tactical:** Small, square buttons with monospaced Geist icons.

### Panels & Cards
- All panels must feature "Mounting Bolts" in the corners.
- Use a **Halftone Overlay** on the bottom 20% of the panel background to create a gradient effect that feels printed rather than rendered.
- Headers are separated by a 1px horizontal line that extends 5px beyond the panel's internal width.

### Input Fields
- Underlined style rather than a full box.
- Active state changes the underline to a glowing Neon Cyan with a blinking terminal cursor.

### Chips & Badges
- Used for resource counts (e.g., "1.2k Ore").
- Rectangular with 0px radius. Use the faction color as a left-side 4px "accent bar" within the chip.

### Progress Bars (Hull Integrity/Loading)
- Segmented bars (dashed) rather than a solid fill.
- The "fill" color should flicker slightly to simulate a worn power supply.