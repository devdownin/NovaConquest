# NOVA EMPIRE - Spécifications Techniques et Fonctionnelles (Audit Complet)
Ce document edcrit le projet de jeu android Nova Empire, les mécaniques de jeu, l'architecture des écrans, le moteur, la gestion des cartes, les factions et l'équilibrage.
## 1. Description Écran par Écran et Enchaînements
L'application repose sur un flux d'écrans (`NavHost` Compose) géré par un `GameViewModel`. Le style UI ("Graphic Noir Futurism" / Style Bilal) est appliqué de manière cohérente : fonds sombres (`#111316`), typographie contrastée (Inter/Rajdhani), effets de verre dépoli, bords néon, overlays demi-teintes et bruit statique, complétés de boulons industriels aux coins (`mountingBolts`).
**Flux de navigation :**
1.  **Loading Screen** : Écran d'initialisation (chargement des assets et plugins de rendu, nettoyage des fichiers `.tmp` corrompus, vérification des sauvegardes).
2.  **Main Menu (Menu Principal)** : Point d'entrée. Options : Nouvelle Partie, Reprendre (Resume Game), Archive (Campagne), Paramètres.
3.  **Settings (Paramètres)** : Réglages du jeu (audio, notifications, réinitialisation de l'état du tutoriel).
4.  **Faction Selection (Sélection de Faction)** : Choix parmi les 6 factions jouables (Dominion, Traders, Synth, Nomads, Kaelen, Xylar), choix de l'archétype de carte (Spiral, Cluster, Ring) et de la taille de la carte (Petite, Moyenne, Grande, Gigantesque).
5.  **Tactical Map (Game Screen - Écran de Jeu Tactique)** : Cœur de l'expérience.
    *   **HUD** : Affiche les crédits, le tour actuel, la faction active, l'indicateur d'événements galactiques, un bouton "Smart Focus" pour cycler les unités inactives, et un bouton "Fin de Tour".
    *   **Interaction** : Vue hexagonale (Zoom In/Tactique/Galactique). "Tap-to-Select" sur une case déclenchant l'affichage contextuel des actions (Move, Attack, Hold, Scout, Disband, Info, Assign) dans une barre d'action latérale ou inférieure. "Ghost Move" : glisser pour simuler des mouvements ou des dégâts.
6.  **Combat Preview (Aperçu de Combat)** : Accessible via le Ghost Move sur une cible. Affiche les HP, dégâts prévus, contre-attaques et probabilités de victoire ou destruction.
7.  **Star System Management (Gestion du Système Stellaire)** : Accessible depuis la carte. Permet d'améliorer le système (Niv 1-5), consulter la production, et produire des unités (Scout, Fighter, Cruiser, Battleship, Carrier).
8.  **Tech Tree (Arbre Technologique)** : Écran en plein écran ou modal. Divisé en 3 branches (Militaire, Expansion, Exploration) de 5-6 paliers chacune.
9.  **Diplomacy & Intel (Diplomatie et Renseignement)** : Affiche les factions rencontrées, les traités proposés/actifs, le classement ("Scoreboard") et un journal de bord narratif.
10. **Hero Academy (Académie des Héros)** : Permet de recruter des leaders spéciaux moyennant des crédits et de les assigner aux flottes.
11. **Campaign Archive (Archive)** : Permet de consulter l'historique des parties et les scores.
... (rest of the doc)